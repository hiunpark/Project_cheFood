package com.chefood.controller.party;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.chefood.biz.party.service.IPartyService;
import com.chefood.biz.party.vo.PartyVO;
import com.chefood.biz.party.vo.Party_registerVO;
import com.chefood.biz.user.vo.UserVO;

@Controller
public class PartyController {
	@Autowired
	IPartyService partyService;
	
	// 메인페이지 이동하기(완료)
	@RequestMapping("/main.do")
	public String main(HttpSession session, Model model){
		if(session.getAttribute("user_id")==null){
			model.addAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "index.jsp";
		}
		return "main.jsp";
	}
	
	// 메인페이지 올 때 파티 좌표를 지도에 뿌려주기(ajax)(완료)
	// getMarker.do
	@RequestMapping("/getMarkers.do")
	@ResponseBody
	public ArrayList<PartyVO> getMarker(@RequestParam(value="term", defaultValue="") String term, Model model, HttpSession session){
		String user_id="";
		if(session.getAttribute("user_id")!=null){
			user_id = (String) session.getAttribute("user_id");
		}
		// 좌표, 시간, 메뉴
		// table: party
		// param: 없음 result:lat, lng, menu, time 
		ArrayList<PartyVO> partyLatLngList = partyService.getPartyLatLng(term);
		for(PartyVO party:partyLatLngList){
			if(party.getChef_id().equals(user_id)){
				party.setChef_id("mine");
			}
		}
		return partyLatLngList;
	}

	// 메뉴 및 파티리스트
	// getPartyList.do(완료)
	@RequestMapping("/getPartyList.do")
	public String getPartyList(Model model, UserVO vo){
		// 이 메서드 하나로 유저 본인과 타인의 파티리스트 전부 조회 가능하게 하기
		// user_id를 ?user_id = id 매개변수로 받아 vo로 쓸 것
		// table: party
		// param: user_id , result: party_seq, chef_id, address, menu, time, max, now
		java.util.Date today = new java.util.Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		ArrayList<PartyVO> usersPartyList = partyService.getPartyList(vo);
		for(PartyVO party:usersPartyList){
			party.setParty_time(party.getParty_time().substring(0, party.getParty_time().lastIndexOf(':')));
			
			String dbTime = party.getParty_time();
			try {
				if(format.parse(dbTime).compareTo(today)<0){
					party.setParty_lat(0.0);
				}
			} catch (ParseException e) {
				e.printStackTrace();
				continue;
			}
		}
		model.addAttribute("user_id", vo.getUser_id());
		model.addAttribute("partyList", usersPartyList);
		return "partyList.jsp";
	}
	
	// 파티 신청자 조회(완료)
	@RequestMapping("/getPartyParticipant.do")
	@ResponseBody
	public ArrayList<UserVO> getPartyParticipant(PartyVO vo, HttpSession session){
		String user_id = "";
		if(session.getAttribute("user_id")!=null){
			user_id = (String)session.getAttribute("user_id");
		}
		// table: party_register, users 조인
		// param: party_seq, result: user_id, user_name, user_birthdate
		ArrayList<UserVO> participants = partyService.getPartyParticipant(vo);
		
		if(!user_id.equals(vo.getChef_id())){
			for(UserVO user:participants){
				user.setAccept(9);
			}
		}
		return participants;
	}
	
	// 파티 신청자의 신청 수락(완료)
	@RequestMapping("/acceptParticipant.do")
	public String acceptParticipant(Party_registerVO regiVO, Model model, HttpSession session){
		String myId = (String) session.getAttribute("user_id");
		// table: party_register
		// param: applicant_id, party_seq
		boolean done = partyService.acceptParticipant(regiVO);
		if(done){
			model.addAttribute("msg", "수락 완료");
			return "getPartyList.do?user_id="+myId;
		}else{
			model.addAttribute("msg", "수락 중 에러 발생");
			return "getPartyList.do?user_id="+myId; 
		}
	}
	
	// 파티 신청자의 신청 거절(완료)
	@RequestMapping("/denyParticipant.do")
	public String denyParticipant(Party_registerVO regiVO, Model model, HttpSession session){
		String myId = (String) session.getAttribute("user_id");
		// table: party_register
		// param: applicant_id, party_seq
		boolean done = partyService.denyParticipant(regiVO);
		if(done){
			model.addAttribute("msg", "거절 완료");
			return "getPartyList.do?user_id="+myId;
		}else{
			model.addAttribute("msg", "거절 중 에러 발생");
			return "getPartyList.do?user_id="+myId; 
		}
	}
	
	// 지도
	// 클릭 시 ajax
	// getPartyInfo.do(완료)
	@RequestMapping("/getPartyInfo.do")
	@ResponseBody
	public PartyVO getPartyInfo(Model model, Party_registerVO regiVO, HttpSession session){
		// 파티 정보 가져오기. party_register에서 내가 신청한 파티인지 확인하여 accept가 2이면 신청중, 1이면 수락, 0이면 거절된 파티
		String user_id = (String)session.getAttribute("user_id");
		if(user_id==null||user_id.equals("")){
			PartyVO noUser = new PartyVO();
			noUser.setChef_id("none");
			return noUser;
		}
		// table: party , party_register
		// param: party_seq, applicant_id result: id, address, menu, time, max, now, accept 조회
		PartyVO clickedParty = partyService.getPartyInfo(regiVO);
		return clickedParty;
	}
	
	// 신청했는지 아닌지 가져오기(완료)
	@RequestMapping("/getRegisterInfo.do")
	@ResponseBody
	public Party_registerVO getRegisterInfo(Party_registerVO regiVO, HttpSession session){
		String user_id = (String)session.getAttribute("user_id");
		regiVO.setApplicant_id(user_id);
		Party_registerVO registerInfo = partyService.getRegisterInfo(regiVO);
		
		PartyVO partyVO = partyService.getPartyInfo(regiVO);
		if(partyVO.getChef_id().equals(user_id)){
			// 내 파티이면 0, 1, 2, 3 이외의 수를 주기
			registerInfo.setAccept(9);
		}
		return registerInfo;
	}
	
	//
	// 신청/취소
	// participate.do(완료)
	// cancelParticipate.do(완료)
	@RequestMapping("/participate.do")
	public String participate(Model model, PartyVO vo, HttpSession session){
		if(session.getAttribute("user_id")==null){
			model.addAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "index.jsp";
		}
		String user_id = (String)session.getAttribute("user_id");
		vo.setChef_id(user_id);
		// insert table: party_register
		// party_seq, user_id을 register 테이블에 삽입
		// 1. party 테이블에 maxPeople과 nowPeople 조회
		// 2. now가 max보다 크거나 같으면 신청 못하고 돌아옴
		// 3. 그렇지 않으면 party_seq, user_id을 register 테이블에 삽입하고
		// 3. party 테이블에서 nowPeople을 1개 늘리기
		boolean participate = partyService.participate(vo);
		String msg = "";
		if(participate){
			msg = "참여 신청하였습니다";
			model.addAttribute("msg", msg);
		}else{
			msg = "신청 가능한 인원이 넘습니다";
			model.addAttribute("msg", msg);
		}
		return "main.do";
	}
	
	@RequestMapping("/cancelParticipate.do")
	public String cancelParticipate(Model model, PartyVO vo, HttpSession session){
		if(session.getAttribute("user_id")==null){
			model.addAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "index.jsp";
		}
		String user_id = (String)session.getAttribute("user_id");
		vo.setChef_id(user_id);
		// delete table: party_register
		// 1. param: party_seq, user_id을 register 테이블에서 삭제
		// 2. party 테이블에서 nowPeople을 1개 줄이기
		boolean cancelParticipate = partyService.cancelParticipate(vo);
		String msg = "";
		if(cancelParticipate){
			msg = "참여 신청이 정상 취소되었습니다";
			model.addAttribute("msg", msg);
		}else{
			msg = "참여 신청 취소 중 에러가 발생했습니다";
			model.addAttribute("msg", msg);
		}
		return "main.do";
	}
	
	// registerParty.jsp 에서 새 파티 등록하기(완료)
	@RequestMapping("/registerParty.do")
	public String registerParty(@RequestParam(value="time") String time, @RequestParam(value="lat") String lat, @RequestParam(value="lng") String lng, PartyVO vo, Model model, HttpSession session){
		if(session.getAttribute("user_id")==null){
			model.addAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "index.jsp";
		}
		vo.setChef_id((String)session.getAttribute("user_id"));
		String newTime = time.substring(0, time.lastIndexOf("T"))+" "+time.substring(time.lastIndexOf("T")+1);
		vo.setParty_time(newTime);
		vo.setParty_lat(Double.parseDouble(lat));
		vo.setParty_lng(Double.parseDouble(lng));
		boolean done = partyService.registerParty(vo);
		if(done){
			model.addAttribute("msg", "새 모임이 등록되었습니다");
			return "getPartyList.do?user_id="+(String)session.getAttribute("user_id");
		}else{
			model.addAttribute("msg", "새 모임 등록 중 에러 발생");
			model.addAttribute("partyInfo", vo);
			return "registerParty.jsp";
		}
	}
	
	// 주소로 좌표 가져오는 ajax(완료)
	@RequestMapping("/getLatLngFromAddress.do")
	@ResponseBody
	public PartyVO getLatLngFromAddress(@RequestParam(value="query", defaultValue="서울시강남구역삼동") String query){
		PartyVO pvo = new PartyVO();
		try {
			Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder()
			                                       .parse("http://openapi.map.naver.com/api/geocode.php?"
			                                       		+ "key=f46c5b0e047ab2d491d6a5fb37498f16"
			                                       		+ "&encoding=utf-8"
			                                       		+ "&coord=latlng"
			                                       		+ "&query="+query);
			// xpath 생성
	        XPath xpath = XPathFactory.newInstance().newXPath();
	        
	        NodeList lat = (NodeList)xpath.evaluate("//item/point/x", document, XPathConstants.NODESET);
	        NodeList lng = (NodeList)xpath.evaluate("//item/point/y", document, XPathConstants.NODESET);
	        String latAvg = "37.5675451";
	        String lngAvg = "126.9773356";
	        if(lat.item(0).getTextContent().trim()!=null&&lng.item(0).getTextContent().trim()!=null){
	        	latAvg = lat.item(0).getTextContent().trim();
	        	lngAvg = lng.item(0).getTextContent().trim();
	        }
        	pvo.setParty_lat(Double.parseDouble(latAvg));
        	pvo.setParty_lng(Double.parseDouble(lngAvg));
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		 return pvo;
	}
	
	@ExceptionHandler(Exception.class)
	public String handleException(Exception ex){
		ex.printStackTrace();
		System.out.println("Exception 발생");
		return "error.jsp";
	}
}
