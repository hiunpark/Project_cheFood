package com.chefood.controller.user;

import java.sql.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.chefood.biz.user.service.IUserService;
import com.chefood.biz.user.vo.UserVO;

@Controller
public class UserController {
	
	@Autowired
	private IUserService userService;
	
	@RequestMapping(method=RequestMethod.POST, value="/login.do")
	public String login(UserVO vo, HttpSession session, Model model){
		
		UserVO user = userService.login(vo);
		
		// 아이디가 없을 경우
		if(user==null){
			model.addAttribute("msg", "아이디를 확인해주세요");
			return "index.jsp";
		
		}else if(!user.getPassword().equals(vo.getPassword())){
			// 아이디는 일치하지만 비밀번호가 일치하지 않을 경우
			model.addAttribute("user_id", vo.getUser_id());
			model.addAttribute("msg", "비밀번호를 확인해주세요");
			return "index.jsp";
		}else{
			// 아이디와 비밀번호 일치
			session.setAttribute("user_id", user.getUser_id());
			session.setAttribute("user_name", user.getUser_name());
			return "main.do";
		}
	}
	
	
	@RequestMapping("/logout.do")
	public String logout(HttpSession session){
		session.invalidate();
		return "index.jsp";
	}
	
	@RequestMapping("/registerUser.do")
	public String registerUser(@RequestParam(value="birthdate") String birth, Model model, UserVO vo){
		Date user_birthdate = Date.valueOf(birth);
		vo.setUser_birthdate(user_birthdate);
		boolean done = userService.registerUser(vo);
		if(done){
			model.addAttribute("msg", "가입 완료! 로그인해주세요");
			return "index.jsp";
		}else{
			model.addAttribute("msg", "가입 실패!");
			return "index.jsp";
		}
	}
}