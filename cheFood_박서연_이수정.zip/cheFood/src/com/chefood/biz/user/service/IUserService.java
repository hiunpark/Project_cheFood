package com.chefood.biz.user.service;

import com.chefood.biz.user.vo.UserVO;

public interface IUserService {

	UserVO login(UserVO vo);

	boolean registerUser(UserVO vo);
}
